import { getStore } from "@netlify/blobs";

const store = getStore("carpinteria-villa-gallery");

export default async (request) => {
  if (request.method === "GET") {
    const data = await store.get("gallery.json", { type: "json" });
    return new Response(JSON.stringify(data || {}), {
      status: 200,
      headers: { "Content-Type": "application/json", "Cache-Control": "no-store" }
    });
  }

  if (request.method === "POST") {
    const expected = process.env.GALLERY_ADMIN_PASSWORD;
    const supplied = request.headers.get("x-admin-password");
    if (!expected || !supplied || supplied !== expected) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { "Content-Type": "application/json" }
      });
    }

    let data;
    try { data = await request.json(); }
    catch { return new Response(JSON.stringify({ error: "Invalid JSON" }), { status: 400, headers: { "Content-Type": "application/json" } }); }

    if (!data || typeof data !== "object" || Array.isArray(data)) {
      return new Response(JSON.stringify({ error: "Invalid data" }), { status: 400, headers: { "Content-Type": "application/json" } });
    }

    await store.setJSON("gallery.json", data);
    return new Response(JSON.stringify({ ok: true }), {
      status: 200,
      headers: { "Content-Type": "application/json", "Cache-Control": "no-store" }
    });
  }

  return new Response("Method Not Allowed", { status: 405 });
};
